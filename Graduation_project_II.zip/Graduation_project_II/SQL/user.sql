-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2022 at 03:04 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `usertype`) VALUES
(1, 'rahmanguhr@gmail.com', 'gouhar184281', 'admin'),
(3, 'gouhar@gmail.com', 'gouhar', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_info`
--

CREATE TABLE `ticket_info` (
  `no` int(110) NOT NULL,
  `ticket_id` int(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_info1`
--

CREATE TABLE `ticket_info1` (
  `no` int(110) NOT NULL,
  `ticket_id` int(200) NOT NULL,
  `price` int(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_info2`
--

CREATE TABLE `ticket_info2` (
  `no` int(110) NOT NULL,
  `ticket_id` int(200) NOT NULL,
  `price` int(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `winners`
--

CREATE TABLE `winners` (
  `no` int(20) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `winners`
--

INSERT INTO `winners` (`no`, `ticket_id`, `price`, `quantity`, `name`, `email`, `address`, `city`, `createdAt`) VALUES
(4, 215548, 10, 1, 'Atif Raza', 'atifrazasgr@gmail.com', 'Lefke gemikonagi northcyprus, 37', 'Lefke', '2022-12-31 14:02:12');

-- --------------------------------------------------------

--
-- Table structure for table `winners2`
--

CREATE TABLE `winners2` (
  `no:` int(11) NOT NULL,
  `ticket_id` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(20) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `winners2`
--

INSERT INTO `winners2` (`no:`, `ticket_id`, `price`, `quantity`, `name`, `email`, `address`, `city`, `createdAt`) VALUES
(8, 893386, 10, 1, 'Arsalan', 'Arsalanalam@gmail.com', 'Lefke', 'lefke', '2022-12-31 14:03:41.662704');

-- --------------------------------------------------------

--
-- Table structure for table `winners3`
--

CREATE TABLE `winners3` (
  `no` int(20) NOT NULL,
  `ticket_id` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `createdAt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `winners3`
--

INSERT INTO `winners3` (`no`, `ticket_id`, `price`, `quantity`, `name`, `email`, `address`, `city`, `createdAt`) VALUES
(7, 865730, 20, 1, 'Gouhar Rahman', 'Gouhar9738@gmail.com', 'Yani Merhala A5 oppo', 'LEFKE', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_info`
--
ALTER TABLE `ticket_info`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `ticket_info1`
--
ALTER TABLE `ticket_info1`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `ticket_info2`
--
ALTER TABLE `ticket_info2`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `winners`
--
ALTER TABLE `winners`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `winners2`
--
ALTER TABLE `winners2`
  ADD PRIMARY KEY (`no:`);

--
-- Indexes for table `winners3`
--
ALTER TABLE `winners3`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ticket_info`
--
ALTER TABLE `ticket_info`
  MODIFY `no` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_info1`
--
ALTER TABLE `ticket_info1`
  MODIFY `no` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_info2`
--
ALTER TABLE `ticket_info2`
  MODIFY `no` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `winners`
--
ALTER TABLE `winners`
  MODIFY `no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `winners2`
--
ALTER TABLE `winners2`
  MODIFY `no:` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `winners3`
--
ALTER TABLE `winners3`
  MODIFY `no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
